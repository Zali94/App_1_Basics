//
//  ViewController.swift
//  BasicsApp
//
//  Created by Z Ali on 2/7/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var viewOne: UIButton!
    @IBOutlet weak var viewTwo: UIButton!
    
    @IBOutlet weak var badButton: UIButton!
    //adding a right button to the bar
    fileprivate func setUpTopRight()
    {
        let addBtn = UIBarButtonItem.init(title: "Add", style: .plain, target: self, action: #selector(addClicked))

        navigationItem.rightBarButtonItem = addBtn
    }
    //setup left bar button item
    fileprivate func setUpTopLeft()
    {
        let removeBtn = UIBarButtonItem.init(title: "Remove", style: .plain, target: self, action:   #selector(removeClicked))
        
        navigationItem.leftBarButtonItem = removeBtn
    }
    //setup middle bar button item
    fileprivate func setUpTopMiddle(){
        let image = UIImage.init(named: "Image")
        let uiImageView = UIImageView.init(image: image)
        
        navigationItem.titleView = uiImageView
    }
    //making manual buttons
    fileprivate func setUpButtonsForSports()
    {
        let x = badButton.frame.origin.x
        let y = badButton.frame.origin.y
        let h = badButton.frame.size.height
        
        let btnArray = ["Soccer", "Basketball", "Football"]
        for i  in 0..<btnArray.count {
            let finalY = y + h + 10
            let btn = UIButton.init()
            btn.frame.origin.x = x
            btn.frame.origin.y = finalY + CGFloat(40*i)
            btn.setTitle(btnArray[i], for: .normal)
            btn.setTitleColor(UIColor.randomColor(), for: .normal)
            btn.addTarget(self, action: #selector(sportButtonClicked), for: UIControl.Event.touchUpInside)
            btn.sizeToFit()
            view.addSubview(btn)
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        setUpTopRight()
        setUpTopLeft()
        setUpTopMiddle()
        
        setUpButtonsForSports()
    }

    
    //adjusting brightness with slider
    @IBAction func Slider(_ sender: UISlider) {
        view.alpha = CGFloat(sender.value)
    }

    
    //clicking the button will allow for the color to change to green
    @objc func addClicked(){
        view.backgroundColor = .green
    }
    //clicking the button will change the color to orange
    @objc func removeClicked(){
        view.backgroundColor = .orange
    }
    
    //pushing to view and changing text depending on what sport item was clicked
    @objc func sportButtonClicked(_ sender:UIButton)
    {
        let st = UIStoryboard.init(name: "Main", bundle: nil)
        
        let vc = st.instantiateViewController(withIdentifier: "detailViewController") as! detailViewController
        
        if sender.titleLabel?.text == "Soccer"{
            vc.sportTitle = "Soccer"
        }
        else if sender.titleLabel?.text == "Basketball"{
            vc.sportTitle = "Basketball"
        }
        else
        {
            vc.sportTitle = "Football"
        }
        navigationController?.pushViewController(vc, animated: true)
    }
    
    //navigation pushes using IBAction
    @IBAction func pushToDetailView(_ sender: UIButton) {
        
        let st = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "detailViewController") as! detailViewController
        
        vc.sportTitle = "View One Button Pushed here"
        
        navigationController?.pushViewController(vc, animated: true)
    }
    @IBAction func viewTwoPush(_ sender: UIButton) {
        let st = UIStoryboard.init(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "detailViewController") as! detailViewController
        
        vc.sportTitle = "View two pushed this"
        
        navigationController?.pushViewController(vc, animated: false)
    }
}

//Inheriting from UIColor
extension UIColor {
    static func randomColor(saturation: CGFloat = 1, brightness: CGFloat = 1, alpha: CGFloat = 1) -> UIColor {
        let hue = CGFloat(arc4random_uniform(361)) / 360.0
        return UIColor(hue: hue, saturation: saturation, brightness: brightness, alpha: alpha)
    }
}
