//
//  detailViewController.swift
//  BasicsApp
//
//  Created by Z Ali on 2/22/22.
//

import UIKit

class detailViewController: UIViewController {

    @IBOutlet weak var lblText: UILabel!
    
    
    var sportTitle: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        lblText.text = sportTitle
    }
    
    
    //popping back to view one using Navigation controller 
    @IBAction func popBackButton(_ sender: UIButton) {
        navigationController?.popViewController(animated: true)
    }
    
    

}
